<?php
class myAuthClass {
    
public static function is_auth()
{
    return true;
}

}