
<!-- Footer -->
<div style="clear:both;"></div>
<footer class="w3-container w3-padding-64 w3-center w3-opacity w3-light-grey w3-xlarge">
  <i class="fab fa-facebook w3-hover-opacity" aria-hidden="true"></i>
  <i class="fab fa-instagram w3-hover-opacity" aria-hidden="true"></i>
  <i class="fab fa-snapchat w3-hover-opacity" aria-hidden="true"></i>
  <i class="fab fa-pinterest-p w3-hover-opacity" aria-hidden="true"></i>
  <i class="fab fa-twitter w3-hover-opacity" aria-hidden="true"></i>
  <i class="fab fa-linkedin w3-hover-opacity" aria-hidden="true"></i>
  <p class="w3-medium">Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a></p>
</footer>